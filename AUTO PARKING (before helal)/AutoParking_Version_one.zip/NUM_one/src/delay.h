/*
 * _delay.h
 *
 *  Created on: Aug 2, 2023
 *      Author: Acer
 */

#ifndef DELAY_H_
#define DELAY_H_



void _delay_ms(unsigned long  Copy_u32Delay);

#endif /* DELAY_H_ */
